﻿#pragma once
#include <iostream>
#include "CPEOPLE.h"
#include "console.h"
#include "Frame.h"
#include "CVEHICLE.h"
#include "CCAR.h"
#include "CTRUCK.h"
#include "CBIRD.h"
#include "CDINAUSOR.h"
#include <thread>
using namespace std;
class CPEOPLE
{
private:
	int mX, mY;
	bool mState; //Trạng thái sống chết
public:
	CPEOPLE();
	CPEOPLE(const CPEOPLE&);
	void set(int x, int y);
	void Up();
	void Left();
	void Right();
	void Down();
	bool isImpact1(CCAR*&, int, bool);
	bool isImpact2(CTRUCK*&, int, bool);
	bool isImpact3(CBIRD*&, int, bool);
	bool isImpact4(CDINAUSOR*&, int, bool);
	void setState(bool a) { mState = a; }
	bool isFinish();
	bool isDead();
	void draw();
	void move(char pressKey, thread& t, bool soundOn); 
	int X() { return mX; }
	int Y() { return mY; }
	void tell();

};

