#pragma once
#include "console.h"
#include "CANIMAL.h"
class CDINAUSOR : public CANIMAL
{
private:
	static const char form[4];
public:
	CDINAUSOR();
	void draw();
	void updatePos();
	void tell();
};



