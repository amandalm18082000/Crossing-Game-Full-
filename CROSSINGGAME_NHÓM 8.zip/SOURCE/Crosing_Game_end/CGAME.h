﻿#pragma once
#include "console.h"
#include "CPEOPLE.h"
#include "CCAR.h"
#include <thread>		
#include "Frame.h"
#include "CTRUCK.h"
#include "CVEHICLE.h"
#include "CBIRD.h"
#include "CDINAUSOR.h"
using namespace std;
class CGAME
{
public:
	static const string MENU[];
	static const string INSTRUCTIONS[];
	static const string SETTINGS[];
private:
	CTRUCK* listTruck;
	CCAR* listCar;
	CDINAUSOR* listDinausor;
	CBIRD* listBird;
	CPEOPLE people;
	Frame box;
	int numTruck;
	int numCar;
	int numDina;
	int numBird;
	bool m_isRunning; // thuộc tính đang chạy có giá trị khởi tạo alway true
	// thuộc tính để đánh dấu game có đang pause hay không, nếu đang pause thì pausing = 1 
	bool pausing;
	int current_level;
public:
	CGAME(); //Chuẩn bị dữ liệu cho tất cả các đối tượng
	CGAME(int, int&, int&);
	CGAME(const CGAME&);
	CGAME& operator= (const CGAME&);
	~CGAME(); // Hủy tài nguyên đã cấp phát
	void setData(int level);
	void drawGame(int&, int&); //Thực hiện vẽ trò chơi ra màn hình sau khi có dữ liệu
	CCAR* getCar() { return listCar; }
	CTRUCK* getTruck() { return listTruck; }
	CBIRD* getBird() { return listBird; }
	CDINAUSOR* getDina() { return listDinausor; }
	CPEOPLE getPeople() { return people; }
	int getNumCar() { return numCar; }
	int getNumTruck() { return numTruck; }
	int getNumBird() { return numBird; }
	int getNumDina() { return numDina; }
	bool isRunning() { return m_isRunning; }
	void setStatePeople(bool a) { people.setState(a); }
	void setterStateOfGame(bool a) { m_isRunning = a; }
	void setLevel(int);
	void clearGame();
	void clearMenuArea(int x, int y, int selecting);
	bool askLast();
	void resetGame(int, int&, int&); // Thực hiện thiết lập lại toàn bộ dữ liệu như lúc đầu
	void drawSettings(int&, int&, int, int);
	void drawMenu(const string a[], const int height, const int width, int selecting, int color, int x, int y);
	void exitGame(thread*); // Thực hiện thoát Thread
	void gameOver(bool);
	bool loadGame(string);// Thực hiện tải lại trò chơi đã lưu
	bool saveGame(string);// Thực hiện lưu lại dữ liệu trò chơi
	void pauseGame(); // Tạm dừng Thread
	void resumeGame(); //Quay lai Thread
	void updatePosPeople(char, thread& t, bool soundOn); //Thực hiện điều khiển di chuyển của CPEOPLE
	void updatePosVehicle(); //Thực hiện cho CTRUCK & CCAR di chuyển
	void updatePosAnimal();//Thực hiện cho CDINAUSOR & CBIRD di chuyển
	void slogan();
	void updateBorder();
	void drawTableMethod();  // vẽ bảng hướng dẫn chơi -  đang làm tạm  // Hong-Tan - W7

	void settings(bool& soundOn, int&, int, int);
	void soundSetting(bool&, int, int);
	int getCurrentLevel() { return current_level; }

	void drawFrame() { box.drawFrame(); }
	void drawLevel();
	void drawTitle();
	void drawInputFile();
	void drawATraffic(int x, int y, int tranfer);
	void drawTraffic();


};