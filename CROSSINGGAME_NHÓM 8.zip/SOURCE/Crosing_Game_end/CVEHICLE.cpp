﻿#include "CVEHICLE.h"
#include "Frame.h"

CVEHICLE::CVEHICLE()
{
	mSpeed = 1;
	mY = 0;
	mX = 0;
}

CVEHICLE& CVEHICLE::operator=(const CVEHICLE& veh)
{
	if (this != &veh)
	{
		mSpeed = veh.mSpeed;
		mX = veh.mX;
		mY = veh.mY;
	}
	return *this;
}
void CVEHICLE::setXY(int x, int y)
{
	mX = x;
	mY = y;
}

void CVEHICLE::setSpeed(int speed)
{
	mSpeed = speed;
}





