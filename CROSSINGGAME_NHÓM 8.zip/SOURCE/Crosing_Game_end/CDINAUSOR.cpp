#include "CDINAUSOR.h"
#include <vector>
CDINAUSOR::CDINAUSOR()
{

}

void CDINAUSOR::draw()
{
	TextColor(14);
	gotoXY(this->X(), this->Y());
	for (int i = 0; i < 4; i++)
		cout << form[i];
}


void CDINAUSOR::updatePos()
{
	this->move();
}

void CDINAUSOR::tell()
{
	PlaySound(TEXT("Sound/dinosaurs.wav"), NULL, SND_FILENAME);
}