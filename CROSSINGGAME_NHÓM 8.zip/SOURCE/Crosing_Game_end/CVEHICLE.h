﻿#pragma once
#include "Frame.h"
#include "console.h"
//#include "CTRAFFICLIGHT.h"
class CVEHICLE
{
protected:
	int mX, mY;
	int mSpeed;
public:
	CVEHICLE();
	CVEHICLE& operator=(const CVEHICLE&);
	int X() { return mX; }
	int Y() { return mY; }
	void setXY(int x, int y);
	void setSpeed(int speed);
	virtual void move() = 0;
};

