#pragma once
#include "CANIMAL.h"
#include <time.h>
class CBIRD : public CANIMAL
{
private:
	unsigned int changeForm;
	static const char form1[3];
	static const char form2[3];

public:
	CBIRD();
	void draw();
	void updatePos();
	void tell();

};
