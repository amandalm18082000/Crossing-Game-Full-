#pragma once
#include "console.h"
#include <vector>
#include "CVEHICLE.h"
#include "Frame.h"
class CCAR : public CVEHICLE
{
public:
	static const char form[4];
	int countTime = 0;
public:
	CCAR();
	void draw();
	void move();
	int getCountTime() { return countTime; }

};


