﻿#include "CGAME.h"
#include "CCAR.h"
#include <string>
#include <Windows.h>
#include <conio.h>
#pragma comment(lib, "winmm.lib")

using namespace std;

const char CTRUCK::form[4] = { char(219), char(219), char(220), char(220) };
const char CCAR::form[4] = { char(220), char(219), char(219), char(220) };
const char CBIRD::form1[3] = { char(223), char(220), char(223) };
const char CBIRD::form2[3] = { char(220), char(223), char(220) };
const char CDINAUSOR::form[4] = { char(223), char(219), char(220), char(196) };
const string CGAME::MENU[] = { "1. New Game","2. Load Game","3. Settings" };


//declare global variables
char MOVING;
int getKey;
bool justWinOrDead = false, soundOn = true;
int menuChoice = 0, setLevel = 1, settingChoice = 0;
CGAME g(1, menuChoice, getKey);
CCAR* listCar = g.getCar();
CTRUCK* listTruct = g.getTruck();
CBIRD* listBird = g.getBird();
CDINAUSOR* listDina = g.getDina();


void drawStartScreen()
{
	g.slogan();
	loadingBar();
	g.drawTitle();
}

void tempSound()
{
	while (1)
	{
		bool running = g.isRunning();
		if (!running)
			return;
		if (soundOn)
		{
			if (setLevel != 2 && setLevel != 3)
			{
				PlaySound(TEXT("Sound/birds.wav"), NULL, SND_FILENAME);
				Sleep(1000);
			}
			if (setLevel != 1)
			{
				PlaySound(TEXT("Sound/dinosaurs.wav"), NULL, SND_FILENAME);
				Sleep(1000);
			}
		}
	}
}

bool waitForDyingEffect = true;

void runGame()
{
	thread sound(tempSound);
	g.drawLevel();
	g.drawFrame();
	while (g.isRunning())
	{
		g.clearGame();
		g.updateBorder();
		listCar = g.getCar();
		listTruct = g.getTruck();
		listBird = g.getBird();
		listDina = g.getDina();
		if (justWinOrDead)
		{
			MOVING = ' ';
			justWinOrDead = false;
		}
		if (!g.getPeople().isDead())
		{
			g.updatePosPeople(MOVING, sound, soundOn);
		}
		MOVING = ' ';
		g.updatePosVehicle();
		g.updatePosAnimal();
		g.drawGame(menuChoice, getKey);

		if (g.getPeople().isImpact1(listCar, g.getNumCar(), soundOn)
			|| g.getPeople().isImpact2(listTruct, g.getNumTruck(), soundOn)
			|| g.getPeople().isImpact3(listBird, g.getNumBird(), soundOn)
			|| g.getPeople().isImpact4(listDina, g.getNumDina(), soundOn))
		{
			g.setStatePeople(false);
			g.pauseGame();
		}

		if (g.getPeople().isDead())
		{
			justWinOrDead = true;

			g.gameOver(soundOn);
			gotoXY(120, 25);
			cout << "GAME OVER";
			gotoXY(105, 26);
			cout << "Press Y to replay, or another key to exit.";
			waitForDyingEffect = false;
			break;
		}

		if (g.getPeople().isFinish())
		{
			justWinOrDead = true;
			gotoXY(109, 26);
			cout << "You crossed the road. What a success =))";
			Sleep(2000);
			if (g.getCurrentLevel() == 6)
			{
				setLevel = 1;
				g.setLevel(1);
				g.resetGame(1, menuChoice, getKey);
			}
			else
			{
				setLevel = setLevel + 1;
				g.setLevel(setLevel);
				g.resetGame(setLevel, menuChoice, getKey);
			}
			clrscr();
			g.drawLevel();
			g.drawFrame();
		}
		Sleep(90);
	}
	sound.join();
}

//run Menu while pausing game
void runMenu(thread& t1)
{
	int getKey;
	string link;
	while (true)
	{
		clrscr();
		g.drawMenu(CGAME::MENU, 3, 11, menuChoice, ColorCode_Green, 120, 20);
		getKey = toupper(_getch());
		if (getKey == 'R')
		{
			gotoXY(120, 25);
			cout << "     ";
			g.resumeGame();
			t1.detach();
			t1 = thread(runGame);
			break;
		}
		if (getKey == 72 || getKey == 80)
		{
			menuChoice += (getKey - 76) / 4 + 3;
			menuChoice %= 3;
		}
		else if (getKey == '\r')
		{
			if (!menuChoice)
			{
				setLevel = 1;
				g.setLevel(1);

				g.resetGame(setLevel, menuChoice, getKey);
				t1.detach();
				t1 = thread(runGame);
				break;
			}
			else if (menuChoice == 1)
			{
				showCursor();
				g.drawInputFile();
				gotoXY(118, 26);
				cout << "input file's name to load game: ";
				gotoXY(118, 27);
				do
				{
					gotoXY(118, 27);
					for (int i = 0; i < link.size(); i++)
						cout << " ";
					gotoXY(118, 27);
					getline(cin, link);
				} while (link.size() > 10);
				bool loaded = g.loadGame(link);
				setLevel = g.getCurrentLevel();

				if (loaded)
				{
					g.clearMenuArea(120, 20, menuChoice);
					g.resumeGame();
					t1.detach();
					t1 = thread(runGame);
					break;
				}
				else
				{
					TextColor(ColorCode_Red);
					gotoXY(40, 30);
					cout << "Cannot open file or incorrect file structure.";
					Sleep(2000);

					gotoXY(40, 31);
					cout << "Please input R two times to continue";
					gotoXY(40, 32);
					system("pause");

					g.clearMenuArea(120, 20, menuChoice);
				}
				hideCursor();
			}
			else
			{
				g.settings(soundOn, settingChoice, 120, 10);
			}
		}
	}
}

int main()
{

	clrscr();
	resizeConsole(1300, 900);
	FixConsoleWindow();
	hideCursor();

	int getKey;
	string link;

	//Lựa chọn lúc bắt đầu
	drawStartScreen();
	while (true)
	{
		g.drawMenu(CGAME::MENU, 3, 11, menuChoice, ColorCode_Green, 120, 20);
		getKey = toupper(_getch());
		if (getKey == 72 || getKey == 80)
		{
			menuChoice += (getKey - 76) / 4 + 3;
			menuChoice %= 3;
		}
		else if (getKey == '\r')
		{
			if (!menuChoice)
			{
				setLevel = 1;
				g.setLevel(1);

				g.resetGame(setLevel, menuChoice, getKey);
				break;
			}
			else if (menuChoice == 1)
			{
				showCursor();
				g.drawInputFile();
				gotoXY(118, 26);
				cout << "input file's name to load game: ";
				gotoXY(118, 27);
				do
				{
					gotoXY(118, 27);
					for (int i = 0; i < link.size(); i++)
						cout << " ";
					gotoXY(118, 27);
					getline(cin, link);
				} while (link.size() > 10);
				bool loaded = g.loadGame(link);
				setLevel = g.getCurrentLevel();
				if (loaded)
				{
					g.clearMenuArea(120, 20, menuChoice);
					hideCursor();
					break;
				}
				else
				{
					TextColor(ColorCode_Red);
					gotoXY(40, 30);
					cout << "Cannot open file or incorrect file structure.";
					Sleep(2000);

					clrscr();
					g.drawTitle();
					g.clearMenuArea(120, 20, menuChoice);
				}
				hideCursor();
			}
			else
			{
				g.settings(soundOn, setLevel, 120, 10);
			}
		}
		else if (getKey == 27)
		{
			return 0;
		}
	}
	//Bắt đầu game
	clrscr();
	thread t1(runGame);
	while (true)
	{
		getKey = toupper(_getch());
		if (!g.getPeople().isDead())
		{
			if (getKey == 27)
			{
				g.exitGame(&t1);
				break;
			}
			else if (getKey == 224)
			{
				getKey = _getch();
				if (getKey == 72 || getKey == 80)
				{
					menuChoice += (getKey - 76) / 4 + 3;
					menuChoice %= 3;
				}
			}
			else if (getKey == 'P')
			{
				gotoXY(120, 25);
				cout << "PAUSE";
				g.pauseGame();
			}
			else if (getKey == 'R')
			{
				gotoXY(120, 25);
				cout << "     ";
				if (!g.isRunning())
				{
					g.resumeGame();
					t1.detach();
					t1 = thread(runGame);
				}
			}
			else if (getKey == 'L')
			{
				showCursor();
				g.pauseGame();
				Sleep(500);
				g.drawInputFile();
				gotoXY(118, 26);
				cout << "input file's name to save game: ";
				do
				{
					gotoXY(118, 27);
					for (int i = 0; i < link.size(); i++)
						cout << " ";
					gotoXY(118, 27);
					getline(cin, link);
				} while (link.size() > 10);
				bool saved = g.saveGame(link);
				if (saved)
				{
					cout << "Game data saved!";
					system("pause");

					gotoXY(118, 26);
					cout << "                     ";
					gotoXY(118, 27);
					cout << "                     ";
					gotoXY(118, 28);
					cout << "                     ";

					gotoXY(117, 26);
					if (g.askLast())
					{
						g.exitGame(&t1);
						break;
					}
					else
					{
						clrscr();
						g.resumeGame();
						t1.detach();
						t1 = thread(runGame);
					}
					hideCursor();
				}
				else
				{
					cout << "Cannot open file.";
					Sleep(2000);
					g.clearMenuArea(120, 20, menuChoice);
					runMenu(t1);
				}
			}
			else if (getKey == 'T')
			{
				g.pauseGame();
				Sleep(500);
				showCursor();
				g.drawInputFile();
				gotoXY(118, 26);
				cout << "input file's name to load game: ";
				gotoXY(118, 27);
				do
				{
					gotoXY(118, 27);
					for (int i = 0; i < link.size(); i++)
						cout << " ";
					gotoXY(118, 27);
					getline(cin, link);
				} while (link.size() > 10);
				bool loaded = g.loadGame(link);
				setLevel = g.getCurrentLevel();
				if (loaded)
				{
					g.clearMenuArea(120, 20, menuChoice);
					g.resumeGame();
					t1.detach();
					t1 = thread(runGame);
				}
				else
				{
					gotoXY(118, 26); cout << "                ";
					gotoXY(118, 27); cout << "                ";
					gotoXY(114, 26);
					cout << "Can't open file or ";
					gotoXY(114, 27);
					cout << "incorrect file structure.";
					Sleep(2000);
					clrscr();
					g.resumeGame();
					t1.detach();
					t1 = thread(runGame);
				}
				hideCursor();
			}
			else if (getKey == '\r')
			{
				g.pauseGame();
				Sleep(500);
				if (!menuChoice)
				{
					setLevel = 1;
					g.setLevel(1);

					g.resetGame(setLevel, menuChoice, getKey);
					g.resumeGame();
					t1.detach();
					t1 = thread(runGame);
					continue;
				}
				else if (menuChoice == 1)
				{
					showCursor();
					g.drawInputFile();
					gotoXY(118, 26);
					cout << "input file's name to load game: ";
					gotoXY(118, 27);
					do
					{
						gotoXY(118, 27);
						for (int i = 0; i < link.size(); i++)
							cout << " ";
						gotoXY(118, 27);
						getline(cin, link);
					} while (link.size() > 10);
					bool loaded = g.loadGame(link);
					setLevel = g.getCurrentLevel();

					if (loaded)
					{
						g.clearMenuArea(120, 20, menuChoice);
						g.resumeGame();
						t1.detach();
						t1 = thread(runGame);
					}
					else
					{
						TextColor(ColorCode_Red);
						gotoXY(40, 30);
						cout << "Cannot open file or incorrect file structure.";
						Sleep(2000);

						gotoXY(40, 31);
						cout << "Please input R two times to continue";
						gotoXY(40, 32);
						system("pause");

						g.clearMenuArea(120, 20, menuChoice);
						runMenu(t1);
					}
					hideCursor();
				}
				else
				{
					g.settings(soundOn, setLevel, 120, 10);
					runMenu(t1);
				}
			}
			else if (g.isRunning())
			{
				MOVING = getKey;
			}
		}
		else
		{
			while (waitForDyingEffect) {}
			if (g.askLast())
			{
				g.exitGame(&t1);
				break;
			}
			else
			{
				clrscr();
				g.resetGame(g.getCurrentLevel(), menuChoice, getKey);
				t1.detach();
				t1 = thread(runGame);
			}
			waitForDyingEffect = true;
		}
	}
	return 0;
}