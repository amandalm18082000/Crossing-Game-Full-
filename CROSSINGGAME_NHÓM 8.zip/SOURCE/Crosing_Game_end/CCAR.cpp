#include "CCAR.h"
#include "console.h"
#include <vector>
#include "Frame.h"
CCAR::CCAR()
{

}

void CCAR::draw()
{
	TextColor(13);
	gotoXY(this->X(), this->Y());
	for (int i = 0; i < 4; i++)
		cout << form[i];
}

void CCAR::move()
{

	countTime++;
	if (countTime >= 100)
	{
		if (mX < Frame::TopRight().X)
			mX = mX;
		else
			mX = Frame::TopLeft().X;
		countTime++;
		if (countTime >= 170)
			countTime = 0;
	}
	else
	{
		if (mX < Frame::TopRight().X)
			mX = mX + 1;
		else
			mX = Frame::TopLeft().X;
	}
}

