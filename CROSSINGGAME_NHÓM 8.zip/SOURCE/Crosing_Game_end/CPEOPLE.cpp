#include "CPEOPLE.h"
#include "Frame.h"
#include <thread>
CPEOPLE::CPEOPLE()
{
	mState = true;
	mY = 0;
	mX = 0;
}

CPEOPLE::CPEOPLE(const CPEOPLE& p)
{
	mState = p.mState;
	mX = p.mX;
	mY = p.mY;
}
void CPEOPLE::set(int x, int y)
{
	mX = x;
	mY = y;
}

void CPEOPLE::Up()
{
	mY = mY - 1;
}

void CPEOPLE::Left()
{
	if (mX > Frame::TopLeft().X + 1)
		mX = mX - 1;
}

void CPEOPLE::Right()
{
	if (mX < Frame::TopRight().X - 1)
		mX = mX + 1;
}

void CPEOPLE::Down()
{
	if (mY < Frame::BottomRight().Y - 2)
		mY = mY + 1;
}

bool CPEOPLE::isDead()
{
	if (mState == true)
		return false;
	return true;
}

bool CPEOPLE::isFinish()
{
	if (mY <= Frame::TopLeft().Y)
		return true;
	return false;
}

void CPEOPLE::draw()
{
	TextColor(ColorCode_White);
	gotoXY(mX, mY);
	cout << char(219);
	gotoXY(mX, mY + 1);
	cout << char(197);
}

void moveSound()
{
	PlaySound(TEXT("sound/cursor-move.wav"), NULL, SND_FILENAME);
}

void CPEOPLE::move(char c, thread& t, bool soundOn)
{
	gotoXY(mX, mY);
	cout << " ";
	gotoXY(mX, mY + 1);
	cout << " ";

	if (c == 'A')
	{
		Left();
		if (soundOn)
		{
			t.detach();
			t = thread(moveSound);
		}
		if (mY == Frame::Line_1().Y || mY == Frame::Line_2().Y ||
			mY == Frame::Line_4().Y || mY == Frame::Line_5().Y)
		{
			TextColor(ColorCode_White);
			gotoXY(mX + 1, mY);
			cout << char(205);
		}
		if (mY == Frame::Line_3().Y)
		{
			TextColor(ColorCode_DarkYellow);
			gotoXY(mX + 1, mY);
			cout << char(220);
		}
		if (mY + 1 == Frame::Line_1().Y || mY + 1 == Frame::Line_2().Y ||
			mY + 1 == Frame::Line_4().Y || mY + 1 == Frame::Line_5().Y)
		{
			TextColor(ColorCode_White);
			gotoXY(mX + 1, mY + 1);
			cout << char(205);
		}
		if (mY + 1 == Frame::Line_3().Y)
		{
			TextColor(ColorCode_DarkYellow);
			gotoXY(mX + 1, mY + 1);
			cout << char(220);
		}


	}
	else if (c == 'D')
	{
		Right();
		if (soundOn)
		{
			t.detach();
			t = thread(moveSound);
		}
		if (mY == Frame::Line_1().Y || mY == Frame::Line_2().Y ||
			mY == Frame::Line_4().Y || mY == Frame::Line_5().Y)
		{
			TextColor(ColorCode_White);
			gotoXY(mX - 1, mY);
			cout << char(205);
		}
		if (mY == Frame::Line_3().Y)
		{
			TextColor(ColorCode_DarkYellow);
			gotoXY(mX - 1, mY);
			cout << char(220);
		}
		if (mY + 1 == Frame::Line_1().Y || mY + 1 == Frame::Line_2().Y ||
			mY + 1 == Frame::Line_4().Y || mY + 1 == Frame::Line_5().Y)
		{
			TextColor(ColorCode_White);
			gotoXY(mX - 1, mY + 1);
			cout << char(205);
		}
		if (mY + 1 == Frame::Line_3().Y)
		{
			TextColor(ColorCode_DarkYellow);
			gotoXY(mX - 1, mY + 1);
			cout << char(220);
		}
	}
	else if (c == 'W')
	{
		Up();
		if (soundOn)
		{
			t.detach();
			t = thread(moveSound);
		}
		if (mY + 2 == Frame::Line_1().Y || mY + 2 == Frame::Line_2().Y ||
			mY + 2 == Frame::Line_4().Y || mY + 2 == Frame::Line_5().Y)
		{
			gotoXY(mX, mY + 2);
			TextColor(ColorCode_White);
			cout << char(205);
		}
		if (mY + 2 == Frame::Line_3().Y)
		{
			TextColor(6);
			gotoXY(mX, mY + 2);
			cout << char(220);
		}
	}
	else if (c == 'S')
	{
		Down();
		if (soundOn)
		{
			t.detach();
			t = thread(moveSound);
		}
		if (mY - 1 == Frame::Line_1().Y || mY - 1 == Frame::Line_2().Y ||
			mY - 1 == Frame::Line_4().Y || mY - 1 == Frame::Line_5().Y)
		{
			gotoXY(mX, mY - 1);
			TextColor(ColorCode_White);
			cout << char(205);
		}
		if (mY - 1 == Frame::Line_3().Y)
		{
			TextColor(6);
			gotoXY(mX, mY - 1);
			cout << char(220);
		}
	}
}

void CPEOPLE::tell()
{
	PlaySound(TEXT("sound/ouch.wav"), NULL, SND_FILENAME);
}
bool CPEOPLE::isImpact1(CCAR*& list, int num, bool soundOn)
{
	/*if (soundOn)
		tell();*/
	for (int i = 0; i < num; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (mX == list[i].X() + j && mY == list[i].Y())
				return true;
			if (mX == list[i].X() + j && mY + 1 == list[i].Y())
				return true;
		}
	}
	return false;
}

bool CPEOPLE::isImpact2(CTRUCK*& list, int num, bool soundOn)
{
	/*if (soundOn)
		tell();*/
	for (int i = 0; i < num; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (mX == list[i].X() + j && mY == list[i].Y())
				return true;
			if (mX == list[i].X() + j && mY + 1 == list[i].Y())
				return true;
		}
	}
	return false;
}

bool CPEOPLE::isImpact3(CBIRD*& list, int num, bool soundOn)
{
	/*if (soundOn)
		tell();*/
	for (int i = 0; i < num; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (mX == list[i].X() + j && mY == list[i].Y())
				return true;
			if (mX == list[i].X() + j && mY + 1 == list[i].Y())
				return true;
		}
	}
	return false;
}

bool CPEOPLE::isImpact4(CDINAUSOR*& list, int num, bool soundOn)
{
	/*if (soundOn)
		tell();*/
	for (int i = 0; i < num; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (mX == list[i].X() + j && mY == list[i].Y())
				return true;
			if (mX == list[i].X() + j && mY + 1 == list[i].Y())
				return true;
		}
	}
	return false;
}