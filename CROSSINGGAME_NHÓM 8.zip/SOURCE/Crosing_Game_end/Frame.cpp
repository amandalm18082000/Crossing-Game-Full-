﻿#include "Frame.h"
#include "console.h"
int Frame::length = 90;
int Frame::width = 35;
int Frame::distance = (Frame::width / 5) - 1;
Point Frame::topLeft = { 3, 6 };
Point Frame::topRight = { Frame::TopLeft().X + Frame::length, Frame::TopLeft().Y };

Point Frame::bottomLeft = { Frame::TopLeft().X, Frame::TopLeft().Y + width + 1 };
Point Frame::bottomRight = { Frame::TopRight().X, Frame::BottomLeft().Y };


Point Frame::line_1 = { Frame::TopLeft().X, Frame::TopLeft().Y + Frame::distance };
Point Frame::line_2 = { Frame::TopLeft().X, Frame::TopLeft().Y + Frame::distance * 2 };
Point Frame::line_3 = { Frame::TopLeft().X, Frame::TopLeft().Y + Frame::distance * 3 };
Point Frame::line_4 = { Frame::TopLeft().X, Frame::TopLeft().Y + Frame::distance * 4 };
Point Frame::line_5 = { Frame::TopLeft().X, Frame::TopLeft().Y + Frame::distance * 5 };

void Frame::drawFrame()
{
	//In viền trên
	TextColor(179);
	gotoXY(topLeft.X + 1, topLeft.Y);
	for (int i = topLeft.X + 1; i <= topRight.X - 1; i++)
		cout << char(223);

	////In viền trái
	int j = 1;
	for (int i = topLeft.Y + 1; i <= bottomLeft.Y - 1; i++)
	{
		gotoXY(topLeft.X, topLeft.Y + j);
		j++;
		cout << char(219);
	}

	//In viền phải
	j = 1;
	for (int i = topRight.Y + 1; i <= bottomRight.Y - 1; i++)
	{
		gotoXY(topRight.X, topRight.Y + j);
		j++;
		cout << char(219);
	}

	//In đường viền biên dưới
	gotoXY(bottomLeft.X + 1, bottomLeft.Y);
	for (int i = bottomLeft.X + 1; i <= bottomRight.X - 1; i++)
		cout << char(223);

	//In hàng 1
	TextColor(ColorCode_White);
	gotoXY(topLeft.X, topLeft.Y + distance);
	for (int i = topLeft.X + 1; i <= topRight.X; i++)
		cout << char(205);

	//In hàng 2
	gotoXY(topLeft.X, topLeft.Y + 2 * distance);
	for (int i = topLeft.X + 1; i <= topRight.X; i++)
		cout << char(205);

	//In hàng 3
	TextColor(6);
	gotoXY(topLeft.X, topLeft.Y + 3 * distance);
	for (int i = topLeft.X + 1; i <= topRight.X; i++)
		cout << char(220);
	TextColor(ColorCode_White);

	//In hàng 4
	gotoXY(topLeft.X, topLeft.Y + 4 * distance);
	for (int i = topLeft.X + 1; i <= topRight.X; i++)
		cout << char(205);

	//In hàng 5
	gotoXY(topLeft.X, topLeft.Y + 5 * distance);
	for (int i = topLeft.X + 1; i <= topRight.X; i++)
		cout << char(205);

	//In các góc

	//In góc phải hàng 1
	gotoXY(topRight.X, topLeft.Y + distance);
	cout << char(219);

	//In góc trái hàng 1
	gotoXY(topLeft.X, topLeft.Y + distance);
	cout << char(219);

	//In góc phải hàng 2
	gotoXY(topRight.X, topLeft.Y + 2 * distance);
	cout << char(219);

	//In góc trái hàng 2
	gotoXY(topLeft.X, topLeft.Y + 2 * distance);
	cout << char(219);

	//In góc phải hàng 3
	gotoXY(topRight.X, topLeft.Y + 3 * distance);
	cout << char(185);

	//In góc trái hàng 3
	gotoXY(topLeft.X, topLeft.Y + 3 * distance);
	cout << char(204);

	//In góc phải hàng 4
	gotoXY(topRight.X, topLeft.Y + 4 * distance);
	cout << char(219);

	//In góc trái hàng 4
	gotoXY(topLeft.X, topLeft.Y + 4 * distance);
	cout << char(219);

	//In góc trái hàng 5
	gotoXY(topLeft.X, topLeft.Y + 5 * distance);
	cout << char(219);

	//In góc phải hàng 5
	gotoXY(topRight.X, topLeft.Y + 5 * distance);
	cout << char(219);

	//In góc phải
	gotoXY(topRight.X, topRight.Y);
	cout << char(187);

	//In góc trái
	gotoXY(topLeft.X, topLeft.Y);
	cout << char(201);

	//In góc đáy trái
	gotoXY(bottomLeft.X, bottomLeft.Y);
	cout << char(200);

	//In góc đáy phải
	gotoXY(bottomRight.X, bottomRight.Y);
	cout << char(188);
	TextColor(ColorCode_Black);
}