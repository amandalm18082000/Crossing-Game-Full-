﻿#include <iostream>
using namespace std;
#pragma once
struct Point
{
	int X, Y;
};
class Frame
{
private:
	static Point topRight, topLeft, bottomRight, bottomLeft,
		line_1, line_2, line_3, line_4, line_5;
	static int length, width, distance;
public:
	static Point TopRight() { return topRight; }
	static Point TopLeft() { return topLeft; }
	static int TopLeft_X() { return topLeft.X; }
	static int Lenght() { return length; }
	static Point BottomRight() { return bottomRight; }
	static Point BottomLeft() { return bottomLeft; }
	static Point Line_1() { return line_1; }
	static Point Line_2() { return line_2; }
	static Point Line_3() { return line_3; }
	static Point Line_4() { return line_4; }
	static Point Line_5() { return line_5; }
	void drawFrame();//Vẽ khung nền

};

