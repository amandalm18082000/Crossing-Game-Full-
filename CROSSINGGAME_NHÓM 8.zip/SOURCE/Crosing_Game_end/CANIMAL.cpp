#include "CANIMAL.h"
#include "Frame.h"
CANIMAL::CANIMAL()
{
	mSpeed = 1;
	mY = 0;
	mX = 0;
}

void CANIMAL::setXY(int x, int y)
{
	mX = x;
	mY = y;
}

void CANIMAL::setSpeed(int speed)
{
	mSpeed = speed;
}

void CANIMAL::move()
{
	if (mX > Frame::TopLeft().X)
		mX = mX - 1;
	else
		mX = Frame::TopRight().X;
}