#include "CBIRD.h"
#include <vector>
CBIRD::CBIRD()
{
	changeForm = 0;
}

void CBIRD::draw()
{
	TextColor(14);
	gotoXY(this->X(), this->Y());
	for (int j = 0; j < 3; j++)
	{
		if ((changeForm % 8 == 0) || ((changeForm - 1) % 8 == 0) || ((changeForm - 2) % 8 == 0) || ((changeForm - 3) % 8 == 0))
			cout << form1[j];
		else 
			cout << form2[j];
	}

	if (changeForm == pow(2, 32) - 1)
		changeForm = 0;
	else
		changeForm++;

}

void CBIRD::updatePos()
{
	this->move();

}

void CBIRD::tell()
{
	PlaySound(TEXT("Sound/birds.wav"), NULL, SND_FILENAME);
}
