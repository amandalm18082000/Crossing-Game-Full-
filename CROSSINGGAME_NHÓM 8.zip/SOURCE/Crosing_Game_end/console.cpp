#include "console.h"
int inputKey()
{
	if (_kbhit())
	{
		int key = _getch();

		if (key == 224)
		{
			key = _getch();
			return key + 1000;
		}

		return key;
	}
	else
	{
		return key_none;
	}

	return key_none;
}


//-------------------------Screen-------------------------
void clrscr()
{
	CONSOLE_SCREEN_BUFFER_INFO	csbiInfo;
	HANDLE	hConsoleOut;
	COORD	Home = { 0,0 };
	DWORD	dummy;

	hConsoleOut = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(hConsoleOut, &csbiInfo);

	FillConsoleOutputCharacter(hConsoleOut, ' ', csbiInfo.dwSize.X * csbiInfo.dwSize.Y, Home, &dummy);
	csbiInfo.dwCursorPosition.X = 0;
	csbiInfo.dwCursorPosition.Y = 0;
	SetConsoleCursorPosition(hConsoleOut, csbiInfo.dwCursorPosition);
}


//screen: goto [x,y]
void gotoXY(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}


//screen: get [x]
int whereX()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi))
		return csbi.dwCursorPosition.X;
	return -1;
}


//screen: get [y]
int whereY()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	if (GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi))
		return csbi.dwCursorPosition.Y;
	return -1;
}


void TextColor(int color)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}


int lengthOfOy()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	int rows;

	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
	rows = csbi.srWindow.Bottom - csbi.srWindow.Top + 1;

	return rows;
}


int lengthOfOx()
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	int columns;

	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
	columns = csbi.srWindow.Right - csbi.srWindow.Left + 1;

	return columns;
}



void resizeConsole(int x, int y)
{
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r);
	MoveWindow(console, r.left, r.top, x, y, TRUE);
}


void FixConsoleWindow()
{

	HWND consoleWindow = GetConsoleWindow();

	LONG style = GetWindowLong(consoleWindow, GWL_STYLE);

	style = style & ~(WS_MAXIMIZEBOX) & ~(WS_THICKFRAME);

	SetWindowLong(consoleWindow, GWL_STYLE, style);
}


void hideCursor()
{
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO info;
	info.dwSize = 100;
	info.bVisible = FALSE;
	SetConsoleCursorInfo(consoleHandle, &info);
}

void showCursor()
{
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO info;
	info.dwSize = 10;
	info.bVisible = TRUE;
	SetConsoleCursorInfo(consoleHandle, &info);
}

void WaitKey()
{
	int i = 0;
	TextColor(0 << 4 | 15);
	gotoXY(55, 22);
	cout << "Press any key to continue ... ";
	while (_kbhit())
		i = _getch(); // Empty the input buffer
	i = _getch(); // Wait for a key
	while (_kbhit())
		i = _getch(); // Empty the input buffer (some keys sends two messages) hence another empty just to be sure
}


void printMe(char ch, int n)
{ // Print out a character ch n times
	for (int i = 0; i < n; i++)
		putchar(ch);
}

void printProgBar(int percent)
{
	string bar;
	string a;
	a.push_back(char(219));
	for (int i = 0; i < 50; i++)
	{
		if (i <= (percent / 2))
		{
			bar.replace(i, 1, a);
		}
		else
		{
			bar.replace(i, 1, " ");
		}
	}
	cout << " [" << bar << "] ";
	cout.width(4);
	cout << percent << "%     " << std::flush;
}

void loadingBar()
{
	int N = 100;
	int y = 15;
	TextColor(ColorCode_DarkYellow);
	int i;
	gotoXY(82, lengthOfOy() / 2 - 4 + 6);
	cout << "Loading.....\n";
	for (i = 0; i < N; i++)
	{
		TextColor(0 << 4 | y);
		y--; // minus 1 to y, for a new color
		if (y < 0 || y == 9) // There are 16 colors.
			y = 15; // if y < 0 or y = 9 (light blue) start colors back at white 
		float p = (i / (float)N) * (float)100;
		gotoXY(60, lengthOfOy() / 2);
		printProgBar(int(p));
		Sleep(100);
	}
	gotoXY(60, lengthOfOy() / 2);
	printProgBar(100);
	clrscr();
	//Sleep(100);
}
