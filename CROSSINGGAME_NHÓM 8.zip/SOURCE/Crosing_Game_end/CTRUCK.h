#pragma once
#include "console.h"
#include "CVEHICLE.h"
class CTRUCK : public CVEHICLE
{
public:
	static const char form[4];
	int countTime = 0;
public:
	CTRUCK();
	void draw();
	void move();
	int getCountTime() { return countTime; }
};

