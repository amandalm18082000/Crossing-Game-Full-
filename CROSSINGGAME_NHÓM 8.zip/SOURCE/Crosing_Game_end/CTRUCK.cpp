#include "CTRUCK.h"
#include <vector>
CTRUCK::CTRUCK()
{

}

void CTRUCK::draw()
{
	TextColor(8);
	gotoXY(this->X(), this->Y());
	for (int i = 0; i < 4; i++)
		cout << form[i];
}


void CTRUCK::move()
{
	countTime++;
	if (countTime >= 60)
	{
		if (mX < Frame::TopRight().X)
			mX = mX;
		else
			mX = Frame::TopLeft().X;
		countTime++;
		if (countTime >= 130)
			countTime = 0;
	}
	else
	{
		if (mX < Frame::TopRight().X)
			mX = mX + 1;
		else
			mX = Frame::TopLeft().X;
	}
}
