#pragma once
#include "Frame.h"
#include "console.h"
class CANIMAL
{
private:
	int mX, mY;
	int mSpeed;
public:
	CANIMAL();
	int X() { return mX; }
	int Y() { return mY; }
	void setXY(int x, int y);
	void setSpeed(int speed);
	virtual void move();
	virtual void tell() = 0;
};