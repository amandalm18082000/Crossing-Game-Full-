﻿#include "CGAME.h"
#include <fstream>
#include <string>
#include <iostream>
using namespace std;
CGAME::CGAME()
{
	listTruck = new CTRUCK;
	listCar = new CCAR;
	listDinausor = new CDINAUSOR;
	listBird = new CBIRD;
	numTruck = 0;
	numCar = 0;
	numDina = 0;
	numBird = 0;
	m_isRunning = true; // m_isRunning khởi tạo true : tức là chương trình đang chạy
	pausing = false; // khởi tạo pausing=false : tức chương trình đang không pause
	current_level = 1;
}

CGAME::CGAME(int level, int& menuChoice, int& getKey)
{
	listTruck = new CTRUCK;
	listCar = new CCAR;
	listDinausor = new CDINAUSOR;
	listBird = new CBIRD;
	numTruck = 0;
	numCar = 0;
	numDina = 0;
	numBird = 0;
	m_isRunning = true; // m_isRunning khởi tạo true : tức là chương trình đang chạy
	pausing = false; // khởi tạo pausing=false : tức chương trình đang không pause
	current_level = level;
	//resetGame(level, menuChoice, getKey);
}

CGAME::CGAME(const CGAME& g)
{
	numTruck = g.numTruck;
	numCar = g.numCar;
	numDina = g.numDina;
	numBird = g.numBird;
	m_isRunning = g.m_isRunning;
	pausing = g.pausing;
	listCar = new CCAR[numCar];
	listTruck = new CTRUCK[numTruck];
	listDinausor = new CDINAUSOR[numDina];
	listBird = new CBIRD[numBird];
	people = g.people;
	box = g.box;
	current_level = g.current_level;
	for (int i = 0; i < numTruck; i++)
		listTruck[i] = g.listTruck[i];
	for (int i = 0; i < numCar; i++)
		listCar[i] = g.listCar[i];
	for (int i = 0; i < numBird; i++)
		listBird[i] = g.listBird[i];
	for (int i = 0; i < numDina; i++)
		listDinausor[i] = g.listDinausor[i];
}

CGAME& CGAME::operator= (const CGAME& g)
{
	if (this != &g)
	{
		delete[]listCar;
		delete[]listTruck;
		delete[]listBird;
		delete[]listDinausor;
		numTruck = g.numTruck;
		numCar = g.numCar;
		numDina = g.numDina;
		numBird = g.numBird;
		m_isRunning = g.m_isRunning;
		pausing = g.pausing;
		listCar = new CCAR[numCar];
		listTruck = new CTRUCK[numTruck];
		listDinausor = new CDINAUSOR[numDina];
		listBird = new CBIRD[numBird];
		people = g.people;
		box = g.box;
		current_level = g.current_level;
		for (int i = 0; i < numTruck; i++)
			listTruck[i] = g.listTruck[i];
		for (int i = 0; i < numCar; i++)
			listCar[i] = g.listCar[i];
		for (int i = 0; i < numBird; i++)
			listBird[i] = g.listBird[i];
		for (int i = 0; i < numDina; i++)
			listDinausor[i] = g.listDinausor[i];
	}
	return *this;
}

CGAME::~CGAME()
{
	delete[]listCar;
	delete[]listTruck;
	delete[]listBird;
	delete[]listDinausor;
}

void CGAME::setData(int level)
{
	current_level = level;
	delete[]listTruck;
	delete[]listCar;
	delete[]listDinausor;
	delete[]listBird;
	if (level == 1)
	{
		numCar = 4;
		numTruck = 0;
		numBird = 4;
		numDina = 0;
	}
	else if (level == 2)
	{
		numCar = 0;
		numTruck = 5;
		numBird = 0;
		numDina = 5;
	}
	else if (level == 3)
	{
		numCar = 5;
		numTruck = 5;
		numBird = 0;
		numDina = 5;
	}
	else if (level == 4)
	{
		numCar = 6;
		numTruck = 0;
		numBird = 6;
		numDina = 6;
	}
	else if (level == 5)
	{
		numCar = 6;
		numTruck = 5;
		numBird = 6;
		numDina = 6;
	}
	else if (level == 6)
	{
		numCar = 6;
		numTruck = 6;
		numBird = 6;
		numDina = 6;
	}
	this->numCar = numCar;
	this->numBird = numBird;
	this->numTruck = numTruck;
	this->numDina = numDina;
	listTruck = new CTRUCK[numTruck];
	listBird = new CBIRD[numBird];
	listCar = new CCAR[numCar];
	listDinausor = new CDINAUSOR[numDina];
	for (int i = 0; i < numCar; i++)
		listCar[i].setXY(((box.Line_4().X + box.Lenght()) / (numCar)) * (i + 1), box.Line_4().Y - 3);
	for (int i = 0; i < numTruck; i++)
		listTruck[i].setXY(((box.Line_5().X + box.Lenght()) / (numTruck)) * (i + 1) + 6, box.Line_5().Y - 3);
	for (int i = 0; i < numBird; i++)
		listBird[i].setXY(((box.Line_2().X + box.Lenght()) / (numBird)) * (i + 1), box.Line_2().Y - 3);
	for (int i = 0; i < numDina; i++)
		listDinausor[i].setXY(((box.Line_3().X + box.Lenght()) / (numDina)) * (i + 1) + 6, box.Line_3().Y - 3);
	people.set(box.Lenght() / 2, box.BottomLeft().Y - 2);
}

void CGAME::drawGame(int& menuChoice, int& getKey)
{
	for (int i = 0; i < numCar; i++)
		listCar[i].draw();
	for (int i = 0; i < numTruck; i++)
		listTruck[i].draw();
	for (int i = 0; i < numBird; i++)
		listBird[i].draw();
	for (int i = 0; i < numDina; i++)
		listDinausor[i].draw();
	people.draw();
	drawMenu(CGAME::MENU, 3, 11, menuChoice, ColorCode_DarkCyan, 120, 20); 
	drawTableMethod();
	drawTraffic();
}

void CGAME::setLevel(int level)
{
	if (level >= 1 && level <= 6)
		current_level = level;
	else
		throw;
}

void CGAME::clearGame()
{
	//clear dinausor
	for (int i = 0; i < numDina; i++)
	{
		gotoXY(listDinausor[i].X(), listDinausor[i].Y());
		if (listDinausor[i].X() < 132)
		{
			for (int j = 0; j < 4; j++)
				cout << ' ';
		}
		else
		{
			for (int j = 0; j < 4; j++)
				cout << ' ';
			gotoXY(listDinausor[i].X(), listDinausor[i].Y());
			TextColor(15);
			cout << char(186);
		}
	}

	//clear car
	for (int i = 0; i < numCar; i++)
	{
		gotoXY(listCar[i].X(), listCar[i].Y());
		if (listCar[i].X() < 132)
		{
			for (int j = 0; j < 4; j++)
				cout << ' ';
		}
		else
		{
			for (int j = 0; j < 4; j++)
				cout << ' ';
			gotoXY(listCar[i].X(), listCar[i].Y());
			TextColor(15);
			cout << char(186);
		}
	}

	//clear truck
	for (int i = 0; i < numTruck; i++)
	{
		gotoXY(listTruck[i].X(), listTruck[i].Y());
		if (listTruck[i].X() < 132)
		{
			for (int j = 0; j < 4; j++)
				cout << ' ';
		}
		else
		{
			for (int j = 0; j < 4; j++)
				cout << ' ';
			gotoXY(listTruck[i].X(), listTruck[i].Y());
			TextColor(15);
			cout << char(186);
		}
	}

	//clear bird
	for (int i = 0; i < numBird; i++)
	{
		gotoXY(listBird[i].X(), listBird[i].Y());
		for (int j = 0; j < 3; j++)
			cout << ' ';
	}

	//clear people
	gotoXY(people.X(), people.Y());
	cout << " ";
	gotoXY(people.X(), people.Y() + 1);
	cout << " ";
}

void CGAME::resetGame(int level, int& menuChoice, int& getKey)
{
	setterStateOfGame(true);
	setStatePeople(true);
	clearGame();
	setData(level);
	drawGame(menuChoice, getKey);
}

void CGAME::exitGame(thread* t)
{
	m_isRunning = false;
	t->join();
}

void CGAME::updatePosPeople(char pressKey, thread& t, bool soundOn)
{
	people.move(pressKey, t, soundOn);
}

void CGAME::updatePosVehicle()
{
	for (int i = 0; i < numCar; i++)
		listCar[i].move();
	for (int i = 0; i < numTruck; i++)
		listTruck[i].move();

}

void CGAME::updatePosAnimal()
{
	for (int i = 0; i < numBird; i++)
		listBird[i].move();
	for (int i = 0; i < numDina; i++)
		listDinausor[i].move();
}

void CGAME::resumeGame()
{
	m_isRunning = true;
}

void CGAME::clearMenuArea(int x, int y, int selecting)
{
	gotoXY(x + 4, y - 1);
	cout << " ";
	for (int i = 0; i < 3; ++i)
	{
		gotoXY(x, y + i);
		if (i != selecting)
		{
			cout << " ";
		}
		else
		{
			cout << " ";
		}
	}
}

void CGAME::drawMenu(const string a[], const int height, const int width, int selecting, int color, int x, int y)
{
	TextColor(ColorCode_White);
	gotoXY(x + 4, y - 1);
	cout << "MENU";
	for (int i = 0; i < 3; ++i)
	{
		gotoXY(x, y + i);
		if (i != selecting)
		{
			cout << a[i].c_str();
		}
		else
		{
			TextColor(color);
			cout << a[i].c_str();
			TextColor(ColorCode_White);
		}
	}
}

void CGAME::pauseGame()
{
	m_isRunning = false;
}

void CGAME::drawLevel()
{
	TextColor(ColorCode_Blue);
	gotoXY(110, 9);
	cout << "LEVEL " << current_level;
	
}

void CGAME::drawTableMethod()
{
	drawLevel();
	TextColor(126);
	gotoXY(110, 30);
	for (int i = 0; i < 34; i++)
		cout << char(223);
	for (int i = 0; i < 14; i++)
	{
		gotoXY(110, 31 + i);
		cout << char(219);
	}

	for (int i = 0; i < 14; i++)
	{
		gotoXY(143, 31 + i);
		cout << char(219);
	}
	gotoXY(110, 44);
	for (int i = 0; i < 34; i++)
		cout << char(223);

	TextColor(ColorCode_DarkWhite);
	gotoXY(120, 28);
	cout << "INTRODUCTION";
	gotoXY(115, 32);
	cout << "ESC : Exit";
	gotoXY(115, 34);
	cout << "P : Pause";
	gotoXY(115, 36);
	cout << "R : Resume";
	gotoXY(115, 38);
	cout << "T : Load game";
	gotoXY(115, 40);
	cout << "L : Save game";
	gotoXY(115, 42);
	cout << "File name limit: 10 letters";
}

void CGAME::drawSettings(int& menuChoice, int& getKey, int x, int y)
{
	int Set[2] = { 7, 7 };
	int counter = 1;
	char key;
	for (int i = 0;;)
	{

		gotoXY(x + 15, y + 12);
		TextColor(Set[0]);
		cout << "1. Sound ";

		gotoXY(x + 15, y + 13);
		TextColor(Set[1]);
		cout << "2. Back ";


		key = _getch();

		if (key == 72 && (counter >= 2 && counter <= 3)) // 72 = up arrow key
		{
			getKey = key;
			counter--;
		}

		if (key == 80 && (counter >= 1 && counter <= 2)) // 80 = down arrow key
		{
			getKey = key;
			counter++;
		}

		if (key == '\r') // carriage return = enter key
		{
			getKey = key;
			if (counter == 1)
			{
				menuChoice = 1;
				return;
			}

			if (counter == 2)
			{
				menuChoice = 2;
				return;
			}
		}

		for (int i = 0; i < 2; i++) 
		{
			Set[i] = 7;
		}

		if (counter == 1)
		{
			Set[0] = 12; // 12 is color red
		}

		else if (counter == 2)
		{
			Set[1] = 12; // 12 is color red
		}
	}
}

void CGAME::updateBorder()
{
	TextColor(179);
	gotoXY(box.Line_2().X + box.Lenght(), box.Line_2().Y - 3);
	cout << char(219);
	gotoXY(box.Line_2().X, box.Line_2().Y - 3);
	cout << char(219);

	//Dinausor
	TextColor(179);
	gotoXY(box.Line_3().X + box.Lenght(), box.Line_3().Y - 3);
	cout << char(219);
	gotoXY(box.Line_3().X, box.Line_3().Y - 3);
	cout << char(219);

	//Car
	TextColor(179);
	gotoXY(box.Line_4().X, box.Line_4().Y - 3);
	cout << char(219);
	gotoXY(box.Line_4().X + box.Lenght(), box.Line_4().Y - 3);
	cout << char(219);

	//Truck
	TextColor(179);
	gotoXY(box.Line_5().X, box.Line_5().Y - 3);
	cout << char(219);
	gotoXY(box.Line_5().X + box.Lenght(), box.Line_5().Y - 3);
	cout << char(219);
	TextColor(ColorCode_Black);
}

bool CGAME::loadGame(string filename)
{
	ifstream f;
	f.open(filename, ios_base::in);
	if (!f.is_open())
	{
		return false;
	}
	int levelCur;
	f >> levelCur;
	int _xCar, _xTruck, _xBird, _xDina, _xP, _yP;
	current_level = levelCur;
	setData(current_level);
	if (numCar == 0)
		f >> _xCar;
	else
	{
		for (int i = 0; i < numCar; i++)
		{
			f >> _xCar;
			listCar[i].setXY(_xCar, box.Line_4().Y - 3);
		}
	}
	if (numTruck == 0)
		f >> _xTruck;
	else
	{
		for (int i = 0; i < numTruck; i++)
		{
			f >> _xTruck;
			listTruck[i].setXY(_xTruck, box.Line_5().Y - 3);
		}
	}
	if (numBird == 0)
		f >> _xBird;
	else
	{
		for (int i = 0; i < numBird; i++)
		{
			f >> _xBird;
			listBird[i].setXY(_xBird, box.Line_2().Y - 3);
		}
	}
	if (numDina == 0)
		f >> _xDina;
	else
	{
		for (int i = 0; i < numDina; i++)
		{
			f >> _xDina;
			listDinausor[i].setXY(_xDina, box.Line_3().Y - 3);
		}
	}
	f >> _xP >> _yP;
	people.set(_xP, _yP);
	clrscr();
	drawFrame();
	drawTableMethod();
	return true;
}

bool CGAME::saveGame(string filename)
{
	ofstream ofs;
	ofs.open(filename, ios::out);
	if (!ofs)
	{
		cout << "Khong the mo file '" << filename << "' !" << endl;
		return false;
	}
	ofs << current_level << endl;
	if (numCar == 0)
		ofs << 0 << endl;
	else
	{
		for (int i = 0; i < numCar; i++)
			ofs << listCar[i].X() << " ";
		ofs << endl;
	}
	if (numTruck == 0)
		ofs << 0 << endl;
	else
	{
		for (int i = 0; i < numTruck; i++)
			ofs << listTruck[i].X() << " ";
		ofs << endl;
	}
	if (numBird == 0)
		ofs << 0 << endl;
	else
	{
		for (int i = 0; i < numBird; i++)
			ofs << listBird[i].X() << " ";
		ofs << endl;
	}
	if (numDina == 0)
		ofs << 0 << endl;
	else
	{
		for (int i = 0; i < numDina; i++)
			ofs << listDinausor[i].X() << " ";
		ofs << endl;
	}
	ofs << people.X() << " " << people.Y();
	ofs.close();
	gotoXY(110, 27);
	cout << "Da luu du lieu vao file " << filename << endl;
	return true;
}

void CGAME::settings(bool& soundOn, int& choiceSettings, int x, int y)
{
	int menuChoice = 0;
	int getKey;

	while (true)
	{
		drawSettings(menuChoice, getKey, x, y);
		if (getKey == 72 || getKey == 80)
		{
			menuChoice += (getKey - 76) / 4 + 3;
			menuChoice %= 3;
		}
		else if (getKey == '\r')
		{
			if (menuChoice == 1)
			{
				soundSetting(soundOn, x, y);
				break;
			}
			else
			{
				choiceSettings = 2;
				gotoXY(40, 30);
				cout << "Please input R two times after input back";
				gotoXY(40, 31);
				system("pause");
				break;
			}
		}
	}
	clrscr();
}

void CGAME::soundSetting(bool& soundOn, int x, int y)
{
	char c;
	do
	{
		gotoXY(x + 32, y + 13);
		if (soundOn)
		{
			cout << char(174);
			TextColor(ColorCode_Green);
			cout << " ON ";
			TextColor(ColorCode_White);
			cout << char(175);
		}
		else
		{
			cout << char(174);
			TextColor(ColorCode_Red);
			cout << " OFF ";
			TextColor(ColorCode_White);
			cout << char(175);
		}

		c = _getch();
		if (c == -32)
		{
			c = _getch();
			if (c == 77 || c == 75)
				soundOn = !soundOn;
		}

	} while (c != '\r');

	TextColor(ColorCode_Red);
	gotoXY(40, 31);
	cout << "Please input R two times to continue";
	gotoXY(40, 32);
	system("pause");

}

void makeSound()
{
	PlaySound(TEXT("sound/explode.wav"), NULL, SND_FILENAME);
}

void CGAME::gameOver(bool soundOn)
{
	int count = 5;
	for (int i = 0; i < count; i++)
	{
		if (soundOn)
			makeSound();
		gotoXY(getPeople().X() - 1, getPeople().Y());
		cout << '*';
		gotoXY(getPeople().X() - 1, getPeople().Y());
		cout << "*";
		gotoXY(getPeople().X() + 1, getPeople().Y());
		cout << "*";
		gotoXY(getPeople().X() + 1, getPeople().Y());
		cout << "*";
		Sleep(100);

		gotoXY(getPeople().X() - 1, getPeople().Y());
		cout << ' ';
		gotoXY(getPeople().X() - 1, getPeople().Y());
		cout << "  ";
		gotoXY(getPeople().X() + 1, getPeople().Y());
		cout << "  ";
		gotoXY(getPeople().X() + 1, getPeople().Y());
		cout << "  ";
		Sleep(200);

		gotoXY(getPeople().X() - 1, getPeople().Y() + 1);
		cout << '*';
		gotoXY(getPeople().X() - 1, getPeople().Y() + 2);
		cout << '*';
		gotoXY(getPeople().X() + 1, getPeople().Y() + 1);
		cout << '*';
		gotoXY(getPeople().X() + 1, getPeople().Y() + 2);
		cout << '*';
		Sleep(200);

		gotoXY(getPeople().X() - 1, getPeople().Y() + 1);
		cout << ' ';
		gotoXY(getPeople().X() - 1, getPeople().Y() + 2);
		cout << ' ';
		gotoXY(getPeople().X() + 1, getPeople().Y() + 1);
		cout << ' ';
		gotoXY(getPeople().X() + 1, getPeople().Y() + 2);
		cout << ' ';
		Sleep(200);
	}
}

bool CGAME::askLast()
{
	gotoXY(105, 27);
	TextColor(ColorCode_White);
	cout << "Do you want to continue playing ?";

	char c;
	int colorYes = ColorCode_Green, colorNo = ColorCode_White;
	bool yes = true;
	do
	{
		gotoXY(140, 27);
		TextColor(colorYes);
		cout << "Yes";
		TextColor(ColorCode_White);
		cout << "/";
		TextColor(colorNo);
		cout << "No";
		c = _getch();
		if (c == -32)
		{
			c = _getch();
			if (c == 75 || c == 77)
			{
				if (!yes)
				{
					colorYes = ColorCode_Red;
					colorNo = ColorCode_White;
					yes = true;

				}
				else
				{
					colorYes = ColorCode_White;
					colorNo = ColorCode_Red;
					yes = false;
				}
			}
		}

	} while (c != '\r');

	if (yes)
		return false;
	return true;
}

void CGAME::drawTitle()
{
	int v3;
	string a[] =
	{
		"   _       __  ______  __      __      ______  ____    __  ___     ______  ____     ",
		"  | |     / / / ____/ / /     / /     / ____/ / __ |  /  |/  /    /_  __/ / __ |    ",
		"  | | /| / / / __/   / /     / /     / /     / / / / / /|_/ /      / /   / / / /    ",
		"  | |/ |/ / / /___  / /___  / /___  / /___  / /_/ / / /  / /      / /   / /_/ /     ",
		"  |__/|__/ /_____/ /_____/ /_____/ |_____/ |_____/ /_/  /_/      /_/   |_____/      ",
		"                                                                                         ",
		"     ______  ____    ____    _____  _____   ____   _   __  ______     ____    ____    ___      ____ ",
		"    / ____/ / __ |  / __ |  / ___/ / ___/ /_  _/  / | / / / ____/    / __ |  / __ |  /   |    / __ |",
		"   / /     / /_/ / / / / / /___ / /___ /   / /   /  |/ / / / __     / /_/ / / / / / / /| |   / / / /",
	    "  / /___  / __ _/ / /_/ / ___/ / ___/ / _ / /_  / /|  / / /_/ /    / __ _/ / /_/ / / ___ |  / /_/ / ",
	    " /_____/ /_/ |_| /_____/ /____/ /___ / /_____/ /_/ |_/ /_____/    /_/ |_| /_____/ /_/  |_| /_____/  ",
	};
	gotoXY(13, 16);
	cout << "\n\n";
	for (int i = 0; i < 11; i++)
	{ 
		v3 = rand() % 15 + 1;
		TextColor(v3);
		cout << a[i].c_str();
		cout << endl;
		Sleep(90);
	}

}
void CGAME::drawInputFile() 
{
	gotoXY(112, 25);
	cout << char(218);//goc trai trên

	for (int j = 0; j <= 3; j++)//vien trai
	{
		gotoXY(112, 26 + j);
		cout << char(179);
	}
	gotoXY(112, 30);
	cout << char(192);

	gotoXY(113, 30);
	for (int i = 0; i < 40; i++)
		cout << char(196);

	cout << char(217);

	gotoXY(113, 25);
	for (int i = 0; i < 40; i++)//vien tren
		cout << char(196);
	cout << char(191);//vien phai tren

	for (int j = 0; j <= 3; j++)//vien phai
	{
		gotoXY(153, 26 + j);
		cout << char(179);
	}
}


void CGAME::slogan()
{
	int len = 0;
	int x, y = 15;
	string name;
	cout << "input your name to start please: ";
	showCursor();
	getline(cin, name);
	clrscr();
	hideCursor();
	string text = "Welcome " + name + " to Crossing Game! Made by team 8\n";
	len = int(text.length());
	gotoXY(55, 20); 

	for (x = 0; x < len; x++)
	{
		TextColor(0 << 4 | y);
		cout << text[x];
		y--; 
		if (y < 0 || y == 9) // There are 16 colors.
			y = 15;  
		Sleep(50); // Pause between letters
	}

	WaitKey(); // Program over, wait for a keypress to close program
	clrscr();
}

void CGAME::drawATraffic(int x, int y, int tranfer)
{
	if (tranfer == 10)
	{
		TextColor(ColorCode_Red);
		gotoXY(x + 1, y - 1);
		cout << char(220);

		TextColor(ColorCode_Grey);
		gotoXY(x + 1, y);
		cout << char(223);
	}
	else
	{
		TextColor(ColorCode_Grey);
		gotoXY(x + 1, y - 1);
		cout << char(220);

		TextColor(ColorCode_Green);
		gotoXY(x + 1, y);
		cout << char(223);
	}
}

void CGAME::drawTraffic()
{
	if (numCar != 0)
	{
		if (listCar[0].getCountTime() >= 100)
		{
			drawATraffic(Frame::Line_4().X + 88, Frame::Line_4().Y - 4, 10);
		}
		else
		{
			drawATraffic(Frame::Line_4().X + 88, Frame::Line_4().Y - 4, 20);
		}
	}
	if (numTruck != 0)
	{
		if (listTruck[0].getCountTime() >= 60)
		{
			drawATraffic(Frame::Line_4().X, Frame::Line_4().Y + 2, 10);
		}
		else
		{
			drawATraffic(Frame::Line_4().X, Frame::Line_4().Y + 2, 20);
		}
	}

}
